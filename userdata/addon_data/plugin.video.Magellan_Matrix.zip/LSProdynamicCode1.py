# -*- coding: utf-8 -*-
#$pyFunction
import re, requests
def GetLSProData(page_data,Cookie_Jar,m):
  list = requests.get('https://www.tdtchannels.com/lists/tv.m3u').text
  data = re.findall('EXTINF.*tvg-logo="([^"]+)".group-title="Informativos".tvg-name="([^"]+)",(.*)\n(.*)',list)
  data.sort()
  return data
