# -*- coding: utf-8 -*-
#$pyFunction
def GetLSProData(page_data, Cookie_Jar, m):
    import os
    import xbmcvfs
    import xbmcaddon
    import xbmcgui
    import zipfile
    import time
    import urllib.request
    import xbmc
    import re
    import glob
    from datetime import datetime
    from sqlite3 import dbapi2 as database

    ADDON = xbmcaddon.Addon()
    ADDONTITLE = ADDON.getAddonInfo('name')
    HOME = xbmcvfs.translatePath('special://home/')
    ADDONS = os.path.join(HOME, 'addons')
    PACKAGES = os.path.join(ADDONS, 'packages')
    DATABASE = xbmcvfs.translatePath('special://database/')

    def latest_db(db):
        match = glob.glob(os.path.join(DATABASE, '{0}*.db'.format(db)))
        comp = '{0}(.+?).db'.format(db[1:])
        highest = 0
        for file in match:
            try:
                check = int(re.compile(comp).findall(file)[0])
            except:
                check = 0
            if highest < check:
                highest = check
        return '{0}{1}.db'.format(db, highest)

    def addon_database(addon=None, state=1, array=False):
        dbfile = latest_db('Addons')
        dbfile = os.path.join(DATABASE, dbfile)
        installedtime = str(datetime.now())[:-7]

        if os.path.exists(dbfile):
            try:
                textdb = database.connect(dbfile)
                textexe = textdb.cursor()
            except Exception as e:
                return False
        else:
            return False

        if state == 2:
            try:
                textexe.execute(
                    "DELETE FROM installed WHERE addonID = ?", (addon,))
                textdb.commit()
                textexe.close()
            except:
                pass
            return True

        try:
            if not array:
                textexe.execute(
                    'INSERT or IGNORE into installed (addonID , enabled, installDate) VALUES (?,?,?)', (addon, state, installedtime,))
                textexe.execute(
                    'UPDATE installed SET enabled = ? WHERE addonID = ? ', (state, addon,))
            else:
                for item in addon:
                    textexe.execute(
                        'INSERT or IGNORE into installed (addonID , enabled, installDate) VALUES (?,?,?)', (item, state, installedtime,))
                    textexe.execute(
                        'UPDATE installed SET enabled = ? WHERE addonID = ? ', (state, item,))
            textdb.commit()
            textexe.close()
        except Exception as e:
            pass

    class Extracter(object):
        def __init__(self, name, _in, _out):
            dialog = xbmcgui.DialogProgress()
            dialog.create(name, "")
            self.all(_in, _out, dialog)

        def all(self, _in, _out, dp):

            zin = zipfile.ZipFile(_in,  'r')

            nFiles = float(len(zin.infolist()))
            count = 0

            try:
                for item in zin.infolist():
                    count += 1
                    update = count / nFiles * 100
                    dp.update(int(update))
                    zin.extract(item, _out)
            except Exception as e:
                return False

            return True

    class Downloader(object):
        def __init__(self, url, name, dest) -> None:
            self.URL = url
            self.NAME = name
            self.DEST = dest
            self.start_time = time.time()

            dialog = xbmcgui.DialogProgress()
            dialog.create(self.NAME, "")

            urllib.request.urlretrieve(
                url, dest, lambda nb, bs, fs: self.downloadPercentage(nb, bs, fs, dialog, name))

        def downloadPercentage(self, nb, bs, fs, dialog, name):
            messages = list()
            try:
                percent = min(nb * bs * 100 / fs, 100)
                currently_downloaded = float(nb) * bs / (1024 * 1024)
                kbps_speed = nb * bs / (time.time() - self.start_time)
                if kbps_speed > 0:
                    eta = (fs - nb * bs) / kbps_speed
                else:
                    eta = 0
                kbps_speed = kbps_speed / 1024
                total = float(fs) / (1024 * 1024)
                messages.append(f'[B]Descargando {name}...[/B]')
                messages.append('%.02f MB de %.02f MB' %
                                (currently_downloaded, total))
                messages.append('Velocidad: %.02f Kb/s ' % kbps_speed)
                messages.append('Tiempo: %02d:%02d' % divmod(eta, 60))
                dialog.update(int(percent), "\n".join(messages))
            except Exception as _:
                percent = 100
                dialog.update(percent)
                dialog.close()

            if dialog.iscanceled():
                dialog.close()

    platforms = None
    
    dest = os.path.join(xbmcvfs.translatePath(PACKAGES),
                        platforms[0].split('/')[-1])
    Downloader(platforms[0], platforms[1], dest)
    Extracter(platforms[1], dest, ADDONS)
    addon_database("plugin.video.elementum", 1)

    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.executebuiltin('UpdateLocalAddons()')
    xbmc.executebuiltin('Container.Refresh()')

